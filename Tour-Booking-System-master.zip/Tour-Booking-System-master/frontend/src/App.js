import "./App.css";
import Layout from "./components/layout/Layout";
import ScrollToTop from "./components/scrollTop/scrollTop"; 

function App() {

  return (
    <>
    <ScrollToTop />
    <Layout />
    </>
    
  )
}
export default App;