import React from "react";

const ThankYouSubscription = () => {
  return (
    <div className="text-center mt-5">
      <h2>🎉 Thank You for Subscribing!</h2>
      <p>You've successfully subscribed to our newsletter and unlocked amazing travel perks.</p>
    </div>
  );
};

export default ThankYouSubscription;
